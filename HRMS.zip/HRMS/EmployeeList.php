<?php


?>

<!DOCTYPE html>
<html>
<body>

<?php

?>

<link rel="stylesheet" href="style.css" type="text/css">


<br> 
<img id= "logo" src="logo.png" width="240" height="100" title="Logo of a company" alt="Logo of a company" />
</br> 
<HR WIDTH="100%" COLOR="#6699FF" SIZE="30">
<HR WIDTH="100%" SIZE="3"> 

<!-- body for registration  -->
<link rel="stylesheet" href="style.css" type="text/css">
<div class="register-form">
  <div class="module">
    <h1>employee list... add your code :) </h1>
    <h1>Mike just a little note for you, I used one css file for all my pages. I would recommend to create a new css file for your pages . copy everything from my style.css to your css file (I know u wont need evrything from my css file but leave it there for the default page layout). that way we wont override each other styles for the pages  :) </h1>
  </div>

<!-- end body  -->

</div>